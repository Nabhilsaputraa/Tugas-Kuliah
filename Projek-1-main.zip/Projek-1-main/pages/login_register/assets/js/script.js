function flipCard() {
    document.getElementById('container').classList.toggle('flip');
}