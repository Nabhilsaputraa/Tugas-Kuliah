-- TABLE USERS: untuk login baik pelatih atau atlet
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('atlet', 'pelatih') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- TABLE ATLET_PROFILE: detail atlet
CREATE TABLE atlet_profile (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    tanggal_lahir DATE,
    jenis_kelamin ENUM('L','P'),
    tinggi_cm FLOAT,
    berat_kg FLOAT,
    cabor VARCHAR(50) NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- TABLE RELASI PELATIH DAN ATLET 
CREATE TABLE pelatih_atlet (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_pelatih INT NOT NULL,
    id_atlet INT NOT NULL,
    tanggal_mulai DATE NOT NULL,
    tanggal_selesai DATE DEFAULT NULL,
    status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
    FOREIGN KEY (id_pelatih) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (id_atlet) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(id_pelatih, id_atlet)
);

-- TABLE FORM_LATIHAN: definisi latihan buatan pelatih
CREATE TABLE form_latihan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_pelatih INT NOT NULL,
    nama_form VARCHAR(100) NOT NULL,
    deskripsi TEXT,
    tanggal_dibuat TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_pelatih) REFERENCES users(id)
);

-- TABLE FORM_FIELD: daftar kolom atau kriteria latihan dalam form
CREATE TABLE form_field (
    id INT AUTO_INCREMENT PRIMARY KEY,
    form_id INT NOT NULL,
    nama_field VARCHAR(100) NOT NULL,
    tipe ENUM('text', 'number', 'date', 'textarea') DEFAULT 'text',
    satuan VARCHAR(50),
    urutan INT,
    FOREIGN KEY (form_id) REFERENCES form_latihan(id) ON DELETE CASCADE
);

-- TABLE HASIL LATIHAN: hasil latihan milik atlet, berdasarkan form
CREATE TABLE hasil_latihan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_form INT NOT NULL,
    id_atlet INT NOT NULL,
    id_pelatih INT NOT NULL,
    tanggal DATE NOT NULL,
    FOREIGN KEY (id_form) REFERENCES form_latihan(id),
    FOREIGN KEY (id_atlet) REFERENCES users(id),
    FOREIGN KEY (id_pelatih) REFERENCES users(id)
);

-- TABLE NILAI_FIELD: nilai masing-masing field yang harus diisi atlet
CREATE TABLE nilai_field (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_hasil INT NOT NULL,
    id_field INT NOT NULL,
    nilai TEXT,
    FOREIGN KEY (id_hasil) REFERENCES hasil_latihan(id) ON DELETE CASCADE,
    FOREIGN KEY (id_field) REFERENCES form_field(id) ON DELETE CASCADE
);
