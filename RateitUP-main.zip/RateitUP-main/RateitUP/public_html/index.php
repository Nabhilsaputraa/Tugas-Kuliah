<?php
require 'setting/config.php'; 

try {
    $sql = "
        SELECT r.*, 
               AVG(rv.rating) as avg_rating,
               COUNT(rv.review_id) as review_count
        FROM restaurants r
        LEFT JOIN reviews rv ON r.restaurant_id = rv.restaurant_id
        GROUP BY r.restaurant_id
        ORDER BY avg_rating DESC
        LIMIT 3
    ";
    
    $stmt = $pdo->query($sql);
    $topRestaurants = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $top3 = [];
    foreach ($topRestaurants as $index => $restaurant) {
        $position = $index + 1;
        $top3[$position] = $restaurant;
    }
    
} catch (PDOException $e) {
    $top3 = [
        1 => ['NAME' => '2:53', 'category' => 'Fine Dining', 'location' => 'New York, USA', 'avg_rating' => 4.8, 'review_count' => 497],
        2 => ['NAME' => 'Gacoan', 'category' => 'Noodle Restaurant', 'location' => 'Batujajar, Bandung Barat', 'avg_rating' => 4.2, 'review_count' => 128],
        3 => ['NAME' => '27:8', 'category' => 'Casual Dining', 'location' => 'Jakarta, Indonesia', 'avg_rating' => 4.0, 'review_count' => 248]
    ];
}

try {
    $reviewsSql = "
        SELECT rv.*, 
               res.NAME as restaurant_name, 
               res.location as restaurant_location,
               u.username as reviewer_name,
               res.category as restaurant_category
        FROM reviews rv
        JOIN restaurants res ON rv.restaurant_id = res.restaurant_id
        JOIN users u ON rv.user_id = u.user_id
        ORDER BY RAND()
        LIMIT 6
    ";
    
    $reviewsStmt = $pdo->query($reviewsSql);
    $randomReviews = $reviewsStmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $randomReviews = [
        [
            'restaurant_name' => 'Neurotox USA',
            'reviewer_name' => 'Kate Bishop',
            'rating' => 4,
            'comment' => 'Tempat dengan konsep unik dan makanan lezat. Pelayanan cepat tapi tempat agak sempit.',
            'created_at' => '2023-05-12',
            'restaurant_location' => '+1 973 428 1166',
            'restaurant_category' => 'Fine Dining'
        ],
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate It Up | Home </title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&family=Bungee&family=Dosis:wght@200..800&family=Emblema+One&family=Lilita+One&family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Oswald:wght@200..700&family=Quicksand:wght@300..700&family=Rubik+Mono+One&family=Signika+Negative:wght@300..700&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- Framework -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        .scrollbar-hide {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        .champion-card {
            transition: all 0.3s ease;
        }
        .champion-card:hover {
            transform: translateY(-5px);
        }
        .first-place {
            transform: scale(1.05);
            z-index: 1;
        }
        body {
            font-family: 'Open Sans', sans-serif;
        }
    </style>
</head>
<body class="overflow-y-scroll scrollbar-hide bg-yellow-100">

    <!-- Navbar section -->
    <header class="sticky top-0 z-50 bg-yellow-100 shadow-sm">
        <section class="container mx-auto flex justify-between items-center py-4 px-6"> 
            <div class="logo">
                <img src="assets/img/vibes-removebg-preview.png" alt="Logo" style="position: absolute; width: 250px; height: auto; left: 0; top: 0;">
            </div>
            <div class="hidden md:flex space-x-8" style="margin-left: 200px;">
                <a href="index.php" class="text-black hover:text-orange-500 font-semibold">Home</a>
                <a href="#p" class="text-black hover:text-orange-500 font-semibold">Top Places</a> 
                <a href="/pages/review_page.php" class="text-black hover:text-orange-500 font-semibold">All Reviews</a> 
            </div>
            <div class="flex space-x-4">
                <a href="/php/login.php" class="px-4 py-2 text-black font-medium hover:text-orange-500 rounded-md">Sign In</a>
                <a href="/php/register.php" class="px-4 py-2 bg-orange-500 text-white font-medium hover:bg-orange-600 rounded-md transition">Sign Up</a>
            </div>
        </section>
    </header> 

    <!-- Hero Section -->
    <section class="bg-yellow-100 py-10">
        <div class="container mx-auto flex flex-col items-center px-6">
            <!-- Bagian Gambar -->
            <div class="mb-10 flex justify-center">
                <img src="assets/img/Premium_Vector___Restaurant_vector_food_menu_icon_cook_fork_symbol_set_dinner_design_knife_illustration-removebg-preview-Pica.png" 
                    alt="Restaurant illustration" 
                    class="w-full max-w-md">
            </div>
            
            <!-- Bagian Teks -->
            <div class="w-full text-center" style="padding: 2rem; border-radius: 0.5rem;">
                <h1 class="text-4xl md:text-5xl font-bold mb-6 text-gray-800">Rate Your Favorite Restaurant</h1>
                <p class="text-lg md:text-xl mb-8 text-gray-600">Share your culinary experience with others and discover hidden gems around you!</p>
                <a href="#" class="inline-block px-8 py-3 bg-orange-500 text-white font-semibold rounded-md hover:bg-orange-600 transition shadow-lg">Write a Review</a>
            </div>
        </div>
    </section>

    <!-- Popular Places Section -->
    <section id="p" class="py-20 bg-orange-500">
        <div class="container mx-auto px-6">
            <!-- Header -->
            <div class="text-center mb-16">
                <h1 class="text-4xl md:text-5xl font-bold mb-4 text-white">TOP PLACES</h1>
                <h3 class="text-xl text-white opacity-90">Don't Miss These 3 Unforgettable Food Spots</h3>
            </div>
            
            <!-- Top 3 Champions Row -->
            <div class="flex flex-col lg:flex-row justify-center items-end gap-8">
                <?php foreach ([2, 1, 3] as $position): ?>
                    <?php if (isset($top3[$position])): ?>
                        <?php $restaurant = $top3[$position]; ?>
                        <div class="champion-card w-full lg:w-<?= $position === 1 ? '1/3' : '1/4' ?> bg-white rounded-xl shadow-xl overflow-hidden transition-all duration-300 hover:shadow-2xl <?= $position === 1 ? 'first-place mt-0 lg:-mt-10' : '' ?>">
                            <div class="<?= $position === 1 ? 'p-8' : 'p-6' ?> text-center h-full flex flex-col">
                                <div class="<?= $position === 1 ? 'text-2xl' : 'text-xl' ?> font-bold text-gray-700 mb-2 
                                    <?= $position === 1 ? 'bg-orange-100' : ($position === 2 ? 'bg-gray-100' : 'bg-amber-100') ?> py-1 rounded-full">
                                    <?= $position ?>st
                                </div>
                                
                                <h2 class="<?= $position === 1 ? 'text-4xl' : 'text-3xl' ?> font-bold text-gray-800 mb-3">
                                    <?= htmlspecialchars($restaurant['NAME']) ?>
                                </h2>
                                
                                <p class="text-gray-600 mb-4">
                                    <?= htmlspecialchars($restaurant['category'] ?? 'Restaurant') ?>
                                </p>
                                
                                <div class="bg-gray-100 p-<?= $position === 1 ? '4' : '3' ?> rounded-lg mb-4">
                                    <div class="text-2xl font-bold text-yellow-500">
                                        <?= str_repeat('★', round($restaurant['avg_rating'])) ?>
                                    </div>
                                    <p class="text-sm text-gray-500 mt-1">
                                        <?= number_format($restaurant['avg_rating'], 1) ?>/5 (<?= $restaurant['review_count'] ?> reviews)
                                    </p>
                                </div>
                                
                                <p class="text-gray-700 <?= $position !== 1 ? 'mt-auto' : '' ?>">
                                    <?= htmlspecialchars($restaurant['location']) ?>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Review Section -->
    <section id="a" class="py-20 bg-gray-50">
        <div class="container mx-auto px-6">
            <div class="text-center mb-16">
                <h1 class="text-4xl md:text-5xl font-bold mb-4 text-gray-800">ALL REVIEWS</h1>
                <p class="text-xl text-gray-600">See what our community is saying</p>
            </div>
            
            <div id="reviewsContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($randomReviews as $review): ?>
                    <div class="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition">
                        <div class="p-6">
                            <div class="flex justify-between items-start mb-4">
                                <div>
                                    <h3 class="text-xl font-bold text-gray-800">
                                        <?= htmlspecialchars($review['restaurant_name']) ?>
                                    </h3>
                                    <p class="text-gray-600">Review oleh: 
                                        <span class="font-medium">
                                            <?= htmlspecialchars($review['reviewer_name']) ?>
                                        </span>
                                    </p>
                                </div>
                                <div class="flex items-center">
                                    <span class="text-yellow-400 text-lg">
                                        <?= str_repeat('★', round($review['rating'])) ?>
                                        <?= str_repeat('☆', 5 - round($review['rating'])) ?>
                                    </span>
                                    <span class="ml-2 text-gray-500">
                                        <?= $review['rating'] ?>/5
                                    </span>
                                </div>
                            </div>
                            <p class="text-gray-700 mb-4">
                                <?= htmlspecialchars($review['comment']) ?>
                            </p>
                            <div class="flex justify-between items-center text-sm text-gray-500">
                                <span>
                                    <?= htmlspecialchars($review['restaurant_location']) ?>
                                </span>
                                <span>
                                    Dikirim pada: <?= date('d M Y', strtotime($review['created_at'])) ?>
                                </span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-12">
                <a href="review.html" class="inline-block px-8 py-3 bg-orange-500 text-white font-semibold rounded-md hover:bg-orange-600 transition shadow-lg">Write a Review</a>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-20 bg-yellow-100">
        <div class="container mx-auto text-center px-6">
            <h2 class="text-3xl md:text-4xl font-bold mb-6 text-gray-800">Ready to Share Your Experience?</h2>
            <p class="text-xl mb-8 text-gray-600 max-w-2xl mx-auto">Join our community of food enthusiasts and help others discover amazing dining experiences</p>
            <div class="flex justify-center space-x-4">
                <a href="register.html" class="px-8 py-3 bg-orange-500 text-white font-semibold rounded-md hover:bg-orange-600 transition shadow-lg">Sign Up Now</a>
                <a href="login.html" class="px-8 py-3 border-2 border-orange-500 text-orange-500 font-semibold rounded-md hover:bg-orange-50 transition">Sign In</a>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="py-12 bg-yellow-100 border-t border-orange-200">
        <div class="container mx-auto px-6">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <!-- Logo dan Copyright -->
                <div class="mb-6 md:mb-0 flex flex-col items-center md:items-start">
                    <img src="assets/img/vibes-removebg-preview.png" alt="Logo" class="mb-4" style="width: 200px;">
                    <p class="text-gray-500 text-sm">© 2025 RateItUp. All rights reserved.</p>
                </div>

                <!-- Link Navigasi -->
                <div class="flex flex-wrap justify-center gap-6">
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">About</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Contact</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Privacy</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Terms</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">FAQ</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Blog</a>
                </div>
            </div>
        </div>
    </footer>

</body>
</html>