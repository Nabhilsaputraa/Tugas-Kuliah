// Checkin
function toggleCheckin(checkbox, restaurantId) {
    fetch('/setting/checkin.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `restaurant_id=${restaurantId}&checked=${checkbox.checked ? '1' : '0'}`
    })
        .then(response => response.text())
        .then(data => {
            if (data.trim() !== 'OK') {
                throw new Error('Failed to update check-in status');
            }
            // Optional: Update UI immediately
            const checkinCountElement = checkbox.closest('.restaurant-card').querySelector('.checkin-count');
            if (checkinCountElement) {
                const currentCount = parseInt(checkinCountElement.textContent);
                checkinCountElement.textContent = checkbox.checked ? currentCount + 1 : currentCount - 1;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            checkbox.checked = !checkbox.checked;
            alert('Failed to update check-in. Please try again.');
        });
}

// Add restorant
document.querySelector('form[action="/setting/add_restaurant.php"]')?.addEventListener('submit', function (e) {
    e.preventDefault();

    const formData = new FormData(this);

    fetch('/setting/add_restaurant.php', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Tambahkan restoran baru ke daftar tanpa refresh
                addRestaurantToUI(data.restaurant);
                this.reset();
                document.getElementById('restaurantForm').classList.add('hidden');
            } else {
                alert(data.error || 'Failed to add restaurant');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to add restaurant. Please try again.');
        });
});

function addRestaurantToUI(restaurant) {
    const restaurantsContainer = document.querySelector('.bg-white.rounded-lg.shadow-md');
    const newRestaurantHTML = `
        <div class="restaurant-card border-b border-gray-200 grid grid-cols-7 gap-4 p-4 items-center hover:bg-gray-50 transition">
            <!-- Isi card restoran baru seperti template yang ada -->
        </div>
    `;

    // Tambahkan di awal daftar
    const firstCard = restaurantsContainer.querySelector('.restaurant-card');
    if (firstCard) {
        firstCard.insertAdjacentHTML('beforebegin', newRestaurantHTML);
    } else {
        restaurantsContainer.insertAdjacentHTML('beforeend', newRestaurantHTML);
    }
}

// Add review and reply
// Handle review submission
document.querySelectorAll('form[action="/setting/add_review.php"]').forEach(form => {
    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);
        const restaurantId = formData.get('restaurant_id');

        fetch('/setting/add_review.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Tambahkan review baru ke UI
                    addReviewToUI(restaurantId, data.review);
                    this.reset();
                } else {
                    alert(data.error || 'Failed to submit review');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to submit review. Please try again.');
            });
    });
});

// Handle reply submission
document.querySelectorAll('form[action="/setting/add_reply.php"]').forEach(form => {
    form.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(this);
        const reviewId = formData.get('review_id');

        fetch('/setting/add_reply.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Tambahkan reply baru ke UI
                    addReplyToUI(reviewId, data.reply);
                    this.reset();
                } else {
                    alert(data.error || 'Failed to submit reply');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Failed to submit reply. Please try again.');
            });
    });
});

