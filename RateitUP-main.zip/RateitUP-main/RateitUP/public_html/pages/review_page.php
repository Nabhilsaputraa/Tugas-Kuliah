<?php
require __DIR__ . '/../setting/config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$isLoggedIn = isset($_SESSION['user_id']);
$currentUserId = $isLoggedIn ? $_SESSION['user_id'] : null;
$isAdmin = $isLoggedIn && 
          !empty($_SESSION['role']) && 
          strtolower(trim($_SESSION['role'])) === 'admin';

$stmt = $pdo->query("SELECT * FROM restaurants ORDER BY created_at DESC");
$restaurants = $stmt->fetchAll();

$sql = "
    SELECT r.*, u.username as creator,
        (SELECT AVG(rating) FROM reviews WHERE restaurant_id = r.restaurant_id) AS avg_rating,
        (SELECT COUNT(*) FROM reviews WHERE restaurant_id = r.restaurant_id) AS review_count,
        " . ($isLoggedIn ? "(SELECT COUNT(*) FROM checkins WHERE restaurant_id = r.restaurant_id AND user_id = :user_id) > 0" : "0") . " AS is_checked,
        " . ($isLoggedIn ? "(SELECT COUNT(*) FROM checkins WHERE restaurant_id = r.restaurant_id AND user_id = :user_id2)" : "0") . " AS checkin_count
    FROM restaurants r
    LEFT JOIN users u ON r.created_by = u.user_id
    ORDER BY r.created_at DESC
";

$reviewsQuery = $pdo->prepare("
    SELECT r.*, u.username 
    FROM reviews r
    JOIN users u ON r.user_id = u.user_id
    WHERE r.restaurant_id = ?
    ORDER BY r.created_at DESC
");

$replyQuery = $pdo->prepare("
    SELECT rr.*, u.username 
    FROM review_replies rr
    JOIN users u ON rr.user_id = u.user_id
    WHERE rr.review_id = ?
    ORDER BY rr.created_at ASC
");

try {
    $stmt = $pdo->prepare($sql);
    if ($isLoggedIn) {
        $stmt->execute(['user_id' => $currentUserId, 'user_id2' => $currentUserId]);
    } else {
        $stmt->execute();
    }
    $restaurants = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "<pre>Query Failed: " . $e->getMessage() . "</pre>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurant Reviews</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .star-rating {
            color: #fbbf24;
            font-size: 1.2rem;
        }
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .login-card {
            width: 100%;
            max-width: 28rem;
        }
        .rating-stars {
            color: #fbbf24;
        }
        .review-content {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out;
        }
        .review-content.expanded {
            max-height: 500px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .toggle-review.active svg {
            transform: rotate(180deg);
        }
        .restaurant-card {
            transition: all 0.2s ease;
        }
        .restaurant-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        }
        .hero-section {
            background: linear-gradient(to right, rgba(234, 88, 12, 0.9), rgba(234, 88, 12, 0.7));
        }
        .floating-decoration {
            animation: float 6s ease-in-out infinite;
        }
        .modal-content {
            animation: modalFadeIn 0.3s ease-out;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="bg-orange-600 font-sans antialiased">
    <!-- Navbar -->
    <header class="sticky top-0 z-50 bg-yellow-100 shadow-sm">
        <section class="container mx-auto flex justify-between items-center py-4 px-6"> 
            <div class="logo">
                <img src="/assets/img/vibes-removebg-preview.png" alt="Logo" style="position: absolute; width: 250px; height: auto; left: 0; top: 0;">
            </div>
            <div class="hidden md:flex space-x-8" style="margin-left: 200px;">
                <a href="/index.php" class="text-black hover:text-orange-500 font-semibold">Home</a>
                <a href="/index.php" class="text-black hover:text-orange-500 font-semibold">Top Places</a> 
                <a href="/pages/review_page.php" class="text-black hover:text-orange-500 font-semibold">All Reviews</a> 
            </div>
            <div class="flex space-x-4 items-center">
                <?php if ($isLoggedIn): ?>
                    <!-- Tampilan ketika user sudah login -->
                    <span class="text-gray-700 font-medium"><?= htmlspecialchars($_SESSION['username'] ?? 'User') ?></span>
                    <a href="/setting/logout.php" class="px-4 py-2 bg-orange-500 text-white font-medium hover:bg-orange-600 rounded-md transition">Logout</a>
                <?php else: ?>
                    <!-- Tampilan ketika user belum login -->
                    <a href="/php/login.php" class="px-4 py-2 text-orange-500 font-medium hover:text-orange-600 rounded-md transition">Sign In</a>
                    <a href="/php/register.php" class="px-4 py-2 bg-orange-500 text-white font-medium hover:bg-orange-600 rounded-md transition">Sign Up</a>
                <?php endif; ?>
                <?php if ($isAdmin): ?>
                    <a href="dasboard.php" class="text-black hover:text-orange-500 font-semibold">Admin Panel</a>
                <?php endif; ?>
            </div>
        </section>
    </header>

    <!-- Hero Section -->
    <section class="hero-section relative overflow-hidden">
        <div class="container mx-auto px-6 py-24 text-center relative z-10">
            <div class="max-w-3xl mx-auto">
                <h1 class="text-5xl font-bold text-white mb-6 leading-tight">Find Your Favorite Restaurant</h1>
                <p class="text-xl text-white opacity-90 mb-10">Share your culinary experience with others and discover hidden gems around you!</p>
            </div>
        </div>
        <div class="absolute left-0 top-0 w-1/3 floating-decoration">
            <img src="/assets/img/Premium_Vector___Restaurant_vector_food_menu_icon_cook_fork_symbol_set_dinner_design_knife_illustration-removebg-preview-Pica.png" alt="Decoration" class="w-full opacity-70">
        </div>
        <div class="absolute right-0 top-0 w-1/4 floating-decoration" style="animation-delay: 1s;">
            <img src="/assets/img/modelo_de_logotipo_de_pizza__adequado_para_logotipo_de_restaurante_e_café-removebg-preview.png" alt="Decoration" class="w-full opacity-70">
        </div>
    </section>

    <!-- Error and success messages -->
    <?php if (isset($_SESSION['error'])): ?>
        <div class="container mx-auto px-6 mt-6">
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?= htmlspecialchars($_SESSION['error']) ?></span>
                <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="this.parentElement.remove()">
                    <svg class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                </span>
            </div>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['success'])): ?>
        <div class="container mx-auto px-6 mt-6">
            <div class="bg-green-100  text-green-700 px-4 py-3 rounded relative" role="alert">
                <span class="block sm:inline"><?= htmlspecialchars($_SESSION['success']) ?></span>
                <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="this.parentElement.remove()">
                    <svg class="fill-current h-6 w-6 text-green-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
                </span>
            </div>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <!-- Main Content -->
    <main class="bg-white rounded-t-3xl -mt-12 relative z-20 pt-12">
        <div class="container mx-auto px-6 py-10">
            <h1 class="text-3xl font-bold text-center mb-10 text-orange-600">Restaurant Reviews</h1>
            
            <!-- Restaurant List -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden">
                <!-- Table Header -->
                <div class="grid grid-cols-7 gap-4 font-semibold text-white bg-orange-600 p-4">
                    <div class="flex items-center">Restaurant Name</div>
                    <div class="flex items-center">Category</div>
                    <div class="flex items-center">Rating</div>
                    <div class="flex items-center">Location</div>
                    <div class="flex items-center justify-center">Check-in</div>
                    <div class="flex items-center justify-center">Total Review</div>
                    <div class="flex items-center justify-center">See Reviews</div>
                </div>

                <!-- Restaurant Items -->
                <?php foreach ($restaurants as $restaurant): 
                    $avgRating = $restaurant['avg_rating'] ? round($restaurant['avg_rating'], 1) : 'No reviews';
                    $stars = $restaurant['avg_rating'] ? str_repeat('★', round($restaurant['avg_rating'])) : '';
                ?>
                <div class="restaurant-card border-b border-gray-200 grid grid-cols-7 gap-4 p-4 items-center hover:bg-gray-50 transition">
                    <div class="font-medium text-gray-800"><?= htmlspecialchars($restaurant['NAME']) ?></div>
                    <div>
                        <span class="bg-yellow-100 text-yellow-800 text-xs px-3 py-1 rounded-full font-medium">
                            <?= htmlspecialchars($restaurant['category']) ?>
                        </span>
                    </div>
                    <div class="flex items-center">
                        <span class="star-rating mr-2"><?= $stars ?></span>
                        <span class="text-gray-600"><?= $avgRating ?></span>
                    </div>
                    <div class="text-gray-600"><?= htmlspecialchars($restaurant['location']) ?></div>
                    <div class="flex justify-center">
                        <form method="POST" action="/setting/checkin.php" class="inline-block">
                            <input type="hidden" name="restaurant_id" value="<?= htmlspecialchars($restaurant['restaurant_id']) ?>">
                            <input type="hidden" name="checked" value="<?= $restaurant['is_checked'] ? '0' : '1' ?>">
                            
                            <button type="submit" class="focus:outline-none flex items-center justify-center">
                                <div class="relative">
                                    <input type="checkbox" 
                                        <?= $restaurant['is_checked'] ? 'checked' : '' ?>
                                        class="hidden">
                                    <div class="w-5 h-5 rounded border-2 <?= $restaurant['is_checked'] ? 'bg-orange-500 border-orange-500' : 'border-gray-300' ?> flex items-center justify-center">
                                        <?php if ($restaurant['is_checked']): ?>
                                            <svg class="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                            </svg>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </button>
                        </form>
                    </div>
                    <div class="flex justify-center">
                        <span class="text-gray-600"><?= $restaurant['review_count'] ?> reviews</span>
                    </div>
                    <div class="flex justify-center">
                        <button class="text-orange-600 hover:text-orange-700 font-medium toggle-review" data-target="review<?= $restaurant['restaurant_id'] ?>">
                            See Reviews
                        </button>
                    </div>
                </div>

                <!-- Review Content -->
                <div id="review<?= $restaurant['restaurant_id'] ?>" class="review-content bg-gray-50">
                    <div class="p-6 overflow-y-scroll" style="max-height: 400px;">
                        <?php
                        $reviewsQuery = $pdo->prepare("
                            SELECT r.*, u.username 
                            FROM reviews r
                            JOIN users u ON r.user_id = u.user_id
                            WHERE r.restaurant_id = ?
                            ORDER BY r.created_at DESC
                        ");
                        $reviewsQuery->execute([$restaurant['restaurant_id']]);
                        $reviews = $reviewsQuery->fetchAll(PDO::FETCH_ASSOC);
                        ?>

                        <?php if (count($reviews) > 0): ?>
                            <h3 class="text-lg font-semibold mb-4 text-gray-800">Customer Reviews</h3>
                            <div class="space-y-4">
                                <?php foreach ($reviews as $review): ?>
                                    <?php $reviewStars = str_repeat('★', round($review['rating'])); ?>
                                    <div class="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
                                        <div class="flex items-start mb-2">
                                            <div class="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center mr-3">
                                                <span class="text-sm text-orange-600 font-bold"><?= strtoupper(substr($review['username'], 0, 2)) ?></span>
                                            </div>
                                            <div class="flex-1">
                                                <div class="flex justify-between items-start">
                                                    <h4 class="text-sm font-semibold text-gray-800"><?= htmlspecialchars($review['username']) ?></h4>
                                                    <div class="text-sm text-orange-500"><?= str_repeat('★', round($review['rating'])) ?></div>
                                                </div>
                                                <p class="text-gray-700 mt-1"><?= htmlspecialchars($review['comment'], ENT_QUOTES, 'UTF-8') ?></p>
                                                <div class="text-xs text-gray-400 mt-2">Posted on <?= date('F j, Y', strtotime($review['created_at'])) ?></div>
                                            </div>
                                        </div>
                                        
                                        <!-- Bagian untuk menampilkan reply -->
                                        <?php
                                        $replyQuery->execute([$review['review_id']]);
                                        $replies = $replyQuery->fetchAll(PDO::FETCH_ASSOC);
                                        ?>

                                        <?php if (!empty($replies)): ?>
                                            <div class="ml-12 mt-4 space-y-3 border-l-2 border-orange-200 pl-4">
                                                <?php foreach ($replies as $reply): ?>
                                                    <div class="bg-gray-50 p-3 rounded-lg relative">
                                                        <?php if ($isLoggedIn && $reply['user_id'] == $currentUserId): ?>
                                                            <div class="absolute top-2 right-2 flex space-x-1">
                                                                <!-- Tombol Edit -->
                                                                <button onclick="openEditReplyModal(
                                                                    <?= $reply['reply_id'] ?>, 
                                                                    '<?= htmlspecialchars(addslashes($reply['reply_text'])) ?>'
                                                                )" class="text-xs p-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                                    </svg>
                                                                </button>
                                                                
                                                                <!-- Tombol Delete -->
                                                                <form method="POST" action="/setting/delete_reply.php" class="inline">
                                                                    <input type="hidden" name="reply_id" value="<?= $reply['reply_id'] ?>">
                                                                    <button type="submit" class="text-xs p-1 bg-red-500 text-white rounded hover:bg-red-600 transition"
                                                                            onclick="return confirm('Delete this reply?')">
                                                                        <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                                        </svg>
                                                                    </button>
                                                                </form>
                                                            </div>
                                                        <?php endif; ?>
                                                        
                                                        <div class="flex items-center mb-1">
                                                            <div class="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mr-2">
                                                                <span class="text-xs text-orange-600 font-bold"><?= strtoupper(substr($reply['username'], 0, 2)) ?></span>
                                                            </div>
                                                            <span class="text-sm font-medium text-gray-700"><?= htmlspecialchars($reply['username']) ?></span>
                                                            <span class="text-xs text-gray-400 ml-2"><?= date('M j, Y', strtotime($reply['created_at'])) ?></span>
                                                        </div>
                                                        <p class="text-gray-600 text-sm ml-10"><?= htmlspecialchars($reply['reply_text']) ?></p>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <!-- add reply -->
                                        <?php if ($isLoggedIn): ?>
                                            <div class="ml-12 mt-3">
                                                <form method="POST" action="/setting/add_reply.php" class="flex gap-2">
                                                    <input type="hidden" name="review_id" value="<?= $review['review_id'] ?>">
                                                    <input type="text" name="reply_text" placeholder="Write a reply..." 
                                                        class="flex-1 text-sm px-3 py-1 border border-gray-300 rounded-full focus:ring-orange-500 focus:border-orange-500" required>
                                                    <button type="submit" 
                                                        class="text-sm px-3 py-1 bg-orange-500 text-white rounded-full hover:bg-orange-600 transition">
                                                        Reply
                                                    </button>
                                                </form>
                                            </div>
                                        <?php endif; ?>

                                        <!-- sCrud -->
                                        <?php if ($isLoggedIn && $review['user_id'] == $currentUserId): ?>
                                            <div class="flex space-x-2 mt-3 ml-12">
                                                <!-- Edit Button -->
                                                <button onclick="openEditModal(<?= $review['review_id'] ?>, '<?= htmlspecialchars(addslashes($review['comment'])) ?>', <?= $review['rating'] ?>)" 
                                                        class="text-xs px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600 transition">Edit
                                                </button> 
                                                <!-- Delete Form -->
                                                <form method="POST" action="/setting/delete_review.php" class="inline">
                                                    <input type="hidden" name="review_id" value="<?= $review['review_id'] ?>">
                                                    <button type="submit" 
                                                            class="text-xs px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 transition"
                                                            onclick="return confirm('Are you sure you want to delete this review?')">
                                                        Delete
                                                    </button>
                                                </form>
                                            </div>
                                        <?php endif; ?>          
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-6 text-gray-500">
                                No reviews yet. Be the first to review!
                            </div>
                        <?php endif; ?>

                        <!-- Add Review Form -->
                        <?php if ($isLoggedIn && $restaurant['is_checked']): ?>
                        <div class="mt-8 bg-white p-6 rounded-lg shadow-sm border border-gray-100">
                            <h3 class="text-lg font-semibold mb-4 text-gray-800">Write a Review</h3>
                            <form method="POST" action="/setting/add_review.php" class="space-y-4">
                                <input type="hidden" name="restaurant_id" value="<?= $restaurant['restaurant_id'] ?>">
                                <div>
                                    <textarea name="comment" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500" placeholder="Share your experience..." rows="3" required></textarea>
                                </div>
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center space-x-2">
                                        <label for="rating" class="text-sm font-medium text-gray-700">Rating:</label>
                                        <select name="rating" required class="border border-gray-300 rounded px-3 py-1 focus:ring-orange-500 focus:border-orange-500">
                                            <option value="5">5 ★★★★★</option>
                                            <option value="4">4 ★★★★☆</option>
                                            <option value="3" selected>3 ★★★☆☆</option>
                                            <option value="2">2 ★★☆☆☆</option>
                                            <option value="1">1 ★☆☆☆☆</option>
                                        </select>
                                    </div>
                                    <button type="submit" name="add_review" class="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition font-medium">
                                        Submit Review
                                    </button>
                                </div>
                            </form>
                        </div>
                        <?php elseif ($isLoggedIn && !$restaurant['is_checked']): ?>
                            <div class="text-center py-4 text-gray-600">
                                Please check-in to this restaurant first to leave a review.
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4 text-gray-600">
                                Please <a href="/login.php" class="text-orange-500 hover:underline">login</a> to leave a review.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Add Restaurant -->
            <?php if (isset($_SESSION['user_id'])): ?>
                <!-- Tombol Toggle -->
                <div class="flex justify-end mt-8">
                    <button 
                        id="toggleFormBtn" 
                        class="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition font-medium">+ Add Restaurant
                    </button>
                </div>

                <!-- add restourant -->
                <div 
                    id="restaurantForm" 
                    class="mx-auto mt-6 bg-white p-6 rounded-xl shadow-md border border-gray-200 hidden"
                >
                    <h2 class="text-xl font-bold text-center text-orange-600 mb-4">Add New Restaurant</h2>
                    <form method="POST" action="/setting/add_restaurant.php" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Restaurant Name</label>
                            <input type="text" name="NAME" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                            <input type="text" name="category" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Location</label>
                            <input type="text" name="location" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500">
                        </div>
                        <div class="flex justify-center pt-2">
                            <button type="submit" name="add_restaurant" class="px-6 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition font-medium">
                                Add Restaurant
                            </button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <!-- Footer Section -->
    <footer class="py-12 bg-yellow-100 border-t border-orange-200">
        <div class="container mx-auto px-6">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <!-- Logo dan Copyright -->
                <div class="mb-6 md:mb-0 flex flex-col items-center md:items-start">
                    <img src="/assets/img/vibes-removebg-preview.png" alt="Logo" class="mb-4" style="width: 200px;">
                    <p class="text-gray-500 text-sm">© 2025 RateItUp. All rights reserved.</p>
                </div>

                <!-- Link Navigasi -->
                <div class="flex flex-wrap justify-center gap-6">
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">About</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Contact</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Privacy</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Terms</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">FAQ</a>
                    <a href="#" class="text-gray-600 hover:text-orange-500 transition">Blog</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Edit Review Modal -->
    <div id="editModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 class="text-lg font-semibold mb-4">Edit Review</h3>
            <form id="editReviewForm" method="POST" action="/setting/update_review.php" class="space-y-4">
                <input type="hidden" id="editReviewId" name="review_id">
                <div>
                    <textarea id="editReviewComment" name="comment" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500" rows="3" required></textarea>
                </div>
                <div class="flex items-center space-x-2">
                    <label for="editReviewRating" class="text-sm font-medium text-gray-700">Rating:</label>
                    <select id="editReviewRating" name="rating" required class="border border-gray-300 rounded px-3 py-1 focus:ring-orange-500 focus:border-orange-500">
                        <option value="5">5 ★★★★★</option>
                        <option value="4">4 ★★★★☆</option>
                        <option value="3">3 ★★★☆☆</option>
                        <option value="2">2 ★★☆☆☆</option>
                        <option value="1">1 ★☆☆☆☆</option>
                    </select>
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="document.getElementById('editModal').classList.add('hidden')" class="px-4 py-2 text-gray-600 hover:text-gray-800">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition">
                        Update Review
                    </button>
                </div>
            </form>
        </div>
    </div>

    <div id="editReplyModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 class="text-lg font-semibold mb-4">Edit Reply</h3>
            <form id="editReplyForm" method="POST" action="/setting/update_reply.php" class="space-y-4">
                <input type="hidden" id="editReplyId" name="reply_id">
                <div>
                    <textarea id="editReplyText" name="reply_text" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-orange-500 focus:border-orange-500" rows="3" required></textarea>
                </div>
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="document.getElementById('editReplyModal').classList.add('hidden')" class="px-4 py-2 text-gray-600 hover:text-gray-800">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition">
                        Update Reply
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openEditReplyModal(replyId, replyText) {
            const modal = document.getElementById('editReplyModal');
            if (!modal) {
                console.error('Reply modal element not found!');
                return;
            }
            
            document.getElementById('editReplyId').value = replyId;
            document.getElementById('editReplyText').value = replyText;
            modal.classList.remove('hidden');
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            // 1. Toggle Check-in Function
            function toggleCheckin(checkbox, restaurantId) {
                const formData = new FormData();
                formData.append('restaurant_id', restaurantId);
                formData.append('checked', checkbox.checked ? '1' : '0');

                fetch('/setting/checkin.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.text();
                })
                .then(data => {
                    if (data.trim() === 'OK') {
                        console.log("Check-in updated.");
                    } else {
                        throw new Error('Invalid server response');
                    }
                })
                .catch(error => {
                    console.error("Error:", error);
                    alert("Failed to update check-in status.");
                    checkbox.checked = !checkbox.checked;
                });
            }

            // 2. Toggle Review Expand/Collapse
            document.querySelectorAll('.toggle-review').forEach(button => {
                button.addEventListener('click', () => {
                    const targetId = button.getAttribute('data-target');
                    const target = document.getElementById(targetId);
                    target.classList.toggle('expanded');
                    button.classList.toggle('active');
                });
            });

            // 3. Toggle Add Restaurant Form
            const toggleBtn = document.getElementById('toggleFormBtn');
            const form = document.getElementById('restaurantForm');
            if (toggleBtn && form) {
                toggleBtn.addEventListener('click', () => {
                    form.classList.toggle('hidden');
                });
            }

            // 4. Edit Review Modal Functionality
            function openEditModal(reviewId, comment, rating) {
                console.log('Opening edit modal for review:', reviewId);
                const modal = document.getElementById('editModal');
                if (!modal) {
                    console.error('Modal element not found!');
                    return;
                }
                
                document.getElementById('editReviewId').value = reviewId;
                document.getElementById('editReviewComment').value = comment;
                document.getElementById('editReviewRating').value = rating;
                modal.classList.remove('hidden');
            }

            // 5. Edit Reply Modal Functionality
            function openEditReplyModal(replyId, replyText) {
                const modal = document.getElementById('editReplyModal');
                if (!modal) {
                    console.error('Reply modal element not found!');
                    return;
                }
                
                document.getElementById('editReplyId').value = replyId;
                document.getElementById('editReplyText').value = replyText;
                modal.classList.remove('hidden');
            }

            // 6. Edit Review Form Submission
            const editReviewForm = document.getElementById('editReviewForm');
            if (editReviewForm) {
                editReviewForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    fetch(this.action, {
                        method: 'POST',
                        body: new FormData(this)
                    })
                    .then(response => {
                        if (!response.ok) throw new Error('Network error');
                        return response.text();
                    })
                    .then(() => {
                        document.getElementById('editModal').classList.add('hidden');
                        window.location.reload();
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Update failed');
                    });
                });
            }

            // 7. Edit Reply Form Submission
            const editReplyForm = document.getElementById('editReplyForm');
            if (editReplyForm) {
                editReplyForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    fetch(this.action, {
                        method: 'POST',
                        body: new FormData(this)
                    })
                    .then(response => {
                        if (!response.ok) throw new Error('Network error');
                        return response.text();
                    })
                    .then(() => {
                        document.getElementById('editReplyModal').classList.add('hidden');
                        window.location.reload();
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Failed to update reply');
                    });
                });
            }

            // 8. Close Modals when clicking outside
            const modals = document.querySelectorAll('.fixed.inset-0'); // Select all fixed position modals
            modals.forEach(modal => {
                modal.addEventListener('click', function(e) {
                    if (e.target === this) {
                        this.classList.add('hidden');
                    }
                });
            });
        });

        window.openEditModal = function(reviewId, comment, rating) {
            console.log('Opening edit modal for review:', reviewId);
            const modal = document.getElementById('editModal');
            if (!modal) {
                console.error('Modal element not found!');
                return;
            }
            
            document.getElementById('editReviewId').value = reviewId;
            document.getElementById('editReviewComment').value = comment;
            document.getElementById('editReviewRating').value = rating;
            modal.classList.remove('hidden');
        };

        function openEditRestaurantModal(restaurantId, name, category, location) {
            const modal = document.getElementById('editRestaurantModal');
            document.getElementById('editRestaurantId').value = restaurantId;
            document.getElementById('editRestaurantName').value = name;
            document.getElementById('editRestaurantCategory').value = category;
            document.getElementById('editRestaurantLocation').value = location;
            modal.classList.remove('hidden');
        }
    </script>
</body>
</html>