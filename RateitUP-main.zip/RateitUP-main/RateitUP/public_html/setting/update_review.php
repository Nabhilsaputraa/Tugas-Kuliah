<?php
// === [1] Error Reporting & Logging ===
ini_set('display_errors', 1);
error_reporting(E_ALL);
file_put_contents('update_debug.log', "\n\n=== NEW UPDATE ATTEMPT ===\n", FILE_APPEND);

// === [2] Start session & Load config ===
session_start();
require 'config.php';

// === [3] Log session and POST data ===
file_put_contents('update_debug.log', "SESSION: " . print_r($_SESSION, true) . "\n", FILE_APPEND);
file_put_contents('update_debug.log', "POST: " . print_r($_POST, true) . "\n", FILE_APPEND);

// === [4] Validasi Login & Metode ===
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Anda harus login terlebih dahulu.";
    header("Location: /php/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Metode tidak valid.";
    header("Location: /pages/review_page.php");
    exit;
}

// === [5] Ambil dan Validasi Input ===
$reviewId = isset($_POST['review_id']) ? (int)$_POST['review_id'] : null;
$comment = trim($_POST['comment'] ?? '');
$rating = isset($_POST['rating']) ? (int)$_POST['rating'] : null;
$userId = $_SESSION['user_id'];

if (!$reviewId || $rating < 1 || $rating > 5) {
    $_SESSION['error'] = "Data tidak valid.";
    file_put_contents('update_debug.log', "Error: Invalid review ID or rating\n", FILE_APPEND);
    header("Location: /pages/review_page.php");
    exit;
}

file_put_contents('update_debug.log', "Prepared Data:\nReview ID: $reviewId\nUser ID: $userId\nComment: $comment\nRating: $rating\n", FILE_APPEND);

// === [6] Proses Update dengan Transaksi ===
try {
    $pdo->beginTransaction();

    // === [6a] Verifikasi review milik user yang sedang login ===
    $checkQuery = "SELECT comment, rating FROM reviews WHERE review_id = ? AND user_id = ?";
    $stmt = $pdo->prepare($checkQuery);
    $stmt->execute([$reviewId, $userId]);
    $existingReview = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$existingReview) {
        file_put_contents('update_debug.log', "Error: Review not found or access denied\n", FILE_APPEND);
        throw new Exception("Review tidak ditemukan atau Anda tidak memiliki izin.");
    }

    // === [6b] Cek apakah ada perubahan data ===
    if ($existingReview['comment'] === $comment && (int)$existingReview['rating'] === $rating) {
        $pdo->rollBack();
        $_SESSION['info'] = "Tidak ada perubahan data yang dilakukan.";
        file_put_contents('update_debug.log', "Info: No changes detected.\n", FILE_APPEND);
        header("Location: /pages/review_page.php");
        exit;
    }

    // === [6c] Eksekusi update ===
    $updateQuery = "UPDATE reviews 
                    SET comment = :comment, rating = :rating, updated_at = NOW() 
                    WHERE review_id = :review_id";
    $stmt = $pdo->prepare($updateQuery);
    $stmt->bindParam(':comment', $comment);
    $stmt->bindParam(':rating', $rating, PDO::PARAM_INT);
    $stmt->bindParam(':review_id', $reviewId, PDO::PARAM_INT);

    $result = $stmt->execute();
    $rowsAffected = $stmt->rowCount();
    $pdo->commit();

    file_put_contents('update_debug.log', "Update Result: " . ($result ? "SUCCESS" : "FAILED") . "\n", FILE_APPEND);
    file_put_contents('update_debug.log', "Rows Affected: $rowsAffected\n", FILE_APPEND);

    if ($rowsAffected > 0) {
        $_SESSION['success'] = "Review berhasil diperbarui.";
    } else {
        $_SESSION['error'] = "Tidak ada perubahan yang dilakukan.";
    }

} catch (PDOException $e) {
    $pdo->rollBack();
    file_put_contents('update_debug.log', "PDO Error: " . $e->getMessage() . "\n", FILE_APPEND);
    $_SESSION['error'] = "Terjadi kesalahan database.";
} catch (Exception $e) {
    $pdo->rollBack();
    file_put_contents('update_debug.log', "General Error: " . $e->getMessage() . "\n", FILE_APPEND);
    $_SESSION['error'] = $e->getMessage();
}

// === [7] Redirect ke halaman review ===
header("Location: /pages/review_page.php");
exit;
