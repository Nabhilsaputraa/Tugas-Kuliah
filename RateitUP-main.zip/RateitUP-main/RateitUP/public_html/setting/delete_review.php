<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "You need to login first";
    header("Location: /php/login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Invalid request";
    header("Location: /pages/review_page.php");
    exit;
}

$reviewId = $_POST['review_id'] ?? null;

// Validasi input
if (empty($reviewId)) {
    $_SESSION['error'] = "Invalid review";
    header("Location: /pages/review_page.php");
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM reviews WHERE review_id = ? AND user_id = ?");
    $stmt->execute([$reviewId, $_SESSION['user_id']]);
    $review = $stmt->fetch();

    if (!$review) {
        $_SESSION['error'] = "Review not found or you don't have permission";
        header("Location: /pages/review_page.php");
        exit;
    }

    // Hapus reply
    $pdo->prepare("DELETE FROM review_replies WHERE review_id = ?")->execute([$reviewId]);
    
    // Hapus review
    $pdo->prepare("DELETE FROM reviews WHERE review_id = ?")->execute([$reviewId]);

    $_SESSION['success'] = "Review deleted successfully";
    header("Location: /pages/review_page.php");
    exit;

} catch (PDOException $e) {
    $_SESSION['error'] = "Database error: " . $e->getMessage();
    header("Location: /pages/review_page.php");
    exit;
}