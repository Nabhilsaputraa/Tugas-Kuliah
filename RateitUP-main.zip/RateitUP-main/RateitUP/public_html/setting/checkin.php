<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = 'Invalid request method';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}

// Check login
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'Please login first';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}

// Validasi
$restaurantId = isset($_POST['restaurant_id']) ? (int)$_POST['restaurant_id'] : 0;
$checked = isset($_POST['checked']) && $_POST['checked'] === '1';

if ($restaurantId <= 0) {
    $_SESSION['error'] = 'Invalid restaurant';
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}

try {
    // Check restaurant
    $stmt = $pdo->prepare("SELECT restaurant_id FROM restaurants WHERE restaurant_id = ?");
    $stmt->execute([$restaurantId]);
    
    if (!$stmt->fetch()) {
        throw new Exception('Restaurant not found');
    }

    // Toggle check-in
    if ($checked) {
        $stmt = $pdo->prepare("
            INSERT INTO checkins (restaurant_id, user_id, created_at) 
            VALUES (?, ?, NOW())
            ON DUPLICATE KEY UPDATE created_at = NOW()
        ");
        $stmt->execute([$restaurantId, $_SESSION['user_id']]);
        $_SESSION['success'] = 'Successfully checked in!';
    } else {
        $stmt = $pdo->prepare("DELETE FROM checkins WHERE restaurant_id = ? AND user_id = ?");
        $stmt->execute([$restaurantId, $_SESSION['user_id']]);
        $_SESSION['success'] = 'Check-in removed';
    }

} catch (PDOException $e) {
    $_SESSION['error'] = 'Database error: ' . $e->getMessage();
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
}

header('Location: ' . $_SERVER['HTTP_REFERER']);
exit;