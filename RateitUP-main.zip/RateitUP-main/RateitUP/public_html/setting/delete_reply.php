<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Invalid request";
    header("Location: /pages/review_page.php");
    exit;
}

$replyId = filter_input(INPUT_POST, 'reply_id', FILTER_VALIDATE_INT);
$userId = $_SESSION['user_id'];

if (!$replyId) {
    $_SESSION['error'] = "Invalid reply ID";
    header("Location: /pages/review_page.php");
    exit;
}

try {
    // Verifikasi kepemilikan reply
    $stmt = $pdo->prepare("SELECT user_id FROM review_replies WHERE reply_id = ?");
    $stmt->execute([$replyId]);
    $ownerId = $stmt->fetchColumn();

    if ($ownerId != $userId) {
        $_SESSION['error'] = "You don't own this reply";
        header("Location: /pages/review_page.php");
        exit;
    }

    // Delete reply
    $deleteStmt = $pdo->prepare("DELETE FROM review_replies WHERE reply_id = ?");
    $deleteStmt->execute([$replyId]);

    $_SESSION['success'] = "Reply deleted successfully!";

} catch (PDOException $e) {
    $_SESSION['error'] = "Database error: " . $e->getMessage();
}

header("Location: /pages/review_page.php");
exit;
?>