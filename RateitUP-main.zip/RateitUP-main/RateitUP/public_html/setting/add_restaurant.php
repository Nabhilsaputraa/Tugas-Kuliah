<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /pages/review_page.php');
    exit;
}

$name = filter_input(INPUT_POST, 'NAME', FILTER_SANITIZE_STRING);
$category = filter_input(INPUT_POST, 'category', FILTER_SANITIZE_STRING);
$location = filter_input(INPUT_POST, 'location', FILTER_SANITIZE_STRING);

if (empty($name) || empty($category) || empty($location)) {
    $_SESSION['error'] = 'All fields are required';
    header('Location: /pages/review_page.php#add-restaurant');
    exit;
}

try {
    $stmt = $pdo->prepare("
        INSERT INTO restaurants (NAME, category, location, created_by, created_at)
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$name, $category, $location, $currentUserId]);

    $_SESSION['success'] = 'Restaurant added successfully';
    header('Location: /pages/review_page.php#add-restaurant');
    exit;
} catch (PDOException $e) {
    error_log("Restaurant addition error: " . $e->getMessage());
    $_SESSION['error'] = 'Failed to add restaurant';
    header('Location: /pages/review_page.php#add-restaurant');
    exit;
}