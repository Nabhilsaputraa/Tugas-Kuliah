<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// REGISTER
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi input
    $errors = [];

    if (strlen($username) < 4) {
        $errors[] = "Username must be at least 4 characters";
    }

    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters";
    }

    if (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter and one number";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("Location: /pages/register.html");
        exit();
    }

    // Cek Username
    $stmt = $pdo->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->execute([$username]);

    if ($stmt->rowCount() > 0) {
        $_SESSION['error'] = "Username already exists";
        header("Location: /php/register.php");
        exit();
    }

    // Hash password
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->execute([$username, $password_hash]);

        $_SESSION['user_id'] = $pdo->lastInsertId();
        $_SESSION['username'] = $username;
        $_SESSION['logged_in'] = true;

        session_regenerate_id(true);

        $_SESSION['success'] = "Registration successful!";
        header("Location: /php/login.php");
        exit();
    } catch (PDOException $e) {
        error_log("Registration error: " . $e->getMessage());
        $_SESSION['error'] = "Registration failed. Please try again.";
        header("Location: /php/register.php");
        exit();
    }
}

// LOGIN - VERSI DIPERBAIKI
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Rate limiting
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 0;
        $_SESSION['last_login_attempt'] = time();
    }

    if ($_SESSION['login_attempts'] >= 5 && time() - $_SESSION['last_login_attempt'] < 300) {
        $_SESSION['error'] = "Too many login attempts. Please try again after 5 minutes.";
        header("Location: /php/login.php");
        exit();
    }

    $stmt = $pdo->prepare("SELECT user_id, username, password, role FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        unset($_SESSION['login_attempts']);
        unset($_SESSION['last_login_attempt']);

        session_regenerate_id(true);

        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = strtolower(trim($user['role'])); 
        $_SESSION['logged_in'] = true;

        if ($_SESSION['role'] === 'admin') {
            header("Location: /pages/review_page.php");
        } else {
            header("Location: /pages/review_page.php");
        }
        exit();
    } else {
        $_SESSION['login_attempts']++;
        $_SESSION['last_login_attempt'] = time();

        $_SESSION['error'] = "Invalid username or password.";
        header("Location: /php/login.php");
        exit();
    }
}
?>
