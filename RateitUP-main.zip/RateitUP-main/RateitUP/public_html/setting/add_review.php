<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "You must be logged in to submit a review.";
    header("Location: /login.php");
    exit;
}

$restaurant_id = $_POST['restaurant_id'] ?? null;
$comment = $_POST['comment'] ?? null;
$rating = $_POST['rating'] ?? null;

// Check Username
$stmt = $pdo->prepare("SELECT COUNT(*) FROM checkins WHERE restaurant_id = ? AND user_id = ?");
$stmt->execute([$restaurant_id, $_SESSION['user_id']]);
$hasCheckedIn = $stmt->fetchColumn();

if (!$hasCheckedIn) {
    $_SESSION['error'] = "You must check-in to this restaurant before submitting a review.";
    header("Location: /pages/review_page.php");
    exit;
}

// Validasi
if (empty($comment) || empty($rating) || !is_numeric($rating) || $rating < 1 || $rating > 5) {
    $_SESSION['error'] = "Invalid review data.";
    header("Location: /pages/review_page.php");
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO reviews (restaurant_id, user_id, comment, rating) VALUES (?, ?, ?, ?)");
    $stmt->execute([$restaurant_id, $_SESSION['user_id'], $comment, $rating]);
    
    $_SESSION['success'] = "Review submitted successfully!";
    header("Location: /pages/review_page.php");
    exit;
} catch (PDOException $e) {
    $_SESSION['error'] = "Failed to submit review: " . $e->getMessage();
    header("Location: /pages/review_page.php");
    exit;
}