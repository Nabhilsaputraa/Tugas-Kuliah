<?php
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = 'Please login to reply';
    header("Location: /login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_id'], $_POST['reply_text'])) {
    try {
        // Validasi input
        $review_id = filter_var($_POST['review_id'], FILTER_VALIDATE_INT);
        $reply_text = trim($_POST['reply_text']);
        
        if (!$review_id || empty($reply_text)) {
            throw new Exception('Invalid input data');
        }

        $stmt = $pdo->prepare("INSERT INTO review_replies (review_id, user_id, reply_text) VALUES (?, ?, ?)");
        $stmt->execute([
            $review_id,
            $_SESSION['user_id'],
            $reply_text
        ]);
        
        $_SESSION['success'] = 'Reply added successfully';
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Failed to add reply: Database error';
    } catch (Exception $e) {
        $_SESSION['error'] = 'Failed to add reply: ' . $e->getMessage();
    }
    
    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit;
}

header("Location: /index.php");
exit;
?>