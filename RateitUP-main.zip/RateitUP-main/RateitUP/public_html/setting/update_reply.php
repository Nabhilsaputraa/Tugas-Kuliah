<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['error'] = "Invalid request";
    header("Location: /pages/review_page.php");
    exit;
}

$replyId = filter_input(INPUT_POST, 'reply_id', FILTER_VALIDATE_INT);
$replyText = trim($_POST['reply_text'] ?? '');
$userId = $_SESSION['user_id'];

if (!$replyId || empty($replyText)) {
    $_SESSION['error'] = "Invalid data";
    header("Location: /pages/review_page.php");
    exit;
}

try {
    // Verifikasi kepemilikan reply
    $stmt = $pdo->prepare("SELECT user_id FROM review_replies WHERE reply_id = ?");
    $stmt->execute([$replyId]);
    $ownerId = $stmt->fetchColumn();

    if ($ownerId != $userId) {
        $_SESSION['error'] = "You don't own this reply";
        header("Location: /pages/review_page.php");
        exit;
    }

    // Update reply
    $updateStmt = $pdo->prepare("UPDATE review_replies SET 
        reply_text = ?, 
        updated_at = NOW() 
        WHERE reply_id = ?");
    
    $updateStmt->execute([$replyText, $replyId]);

    $_SESSION['success'] = "Reply updated successfully!";

} catch (PDOException $e) {
    $_SESSION['error'] = "Database error: " . $e->getMessage();
}

header("Location: /pages/review_page.php");
exit;
?>