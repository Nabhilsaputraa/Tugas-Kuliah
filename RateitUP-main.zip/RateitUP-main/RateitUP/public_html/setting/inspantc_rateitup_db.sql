-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 08, 2025 at 09:15 AM
-- Server version: 10.6.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inspantc_rateitup_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkins`
--

CREATE TABLE `checkins` (
  `checkin_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `restaurant_id` int(11) NOT NULL,
  `checked` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `checkins`
--

INSERT INTO `checkins` (`checkin_id`, `user_id`, `restaurant_id`, `checked`, `created_at`) VALUES
(3, 5, 11, 1, '2025-07-07 15:02:50'),
(17, 1, 16, 0, '2025-07-08 00:25:40');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `restaurant_id` int(11) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `location` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`restaurant_id`, `NAME`, `category`, `location`, `created_by`, `is_verified`, `created_at`) VALUES
(16, 'sdasd', 'asd', 'asd', 1, 0, '2025-07-07 17:49:43'),
(15, 'as', 'saasd', 'asd', 1, 0, '2025-07-07 17:33:07'),
(14, 'rumah makan padang', 'rumah makan padang', 'bandung barat, jawa barat', 1, 0, '2025-07-07 16:52:01'),
(13, 'ts', '12', 'bsd', 1, 0, '2025-07-07 15:20:26'),
(8, 'a', 'a', 'a', 1, 0, '2025-07-07 09:30:19'),
(9, 'aa', 'a', 'a', 1, 0, '2025-07-07 09:30:31'),
(10, '1', '2', '3', 1, 0, '2025-07-07 10:03:35'),
(11, '2', '1', '3', 1, 0, '2025-07-07 10:03:49'),
(12, 'sd', 'Italian', 'asd', 1, 0, '2025-07-07 10:57:51');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `restaurant_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`review_id`, `parent_id`, `restaurant_id`, `user_id`, `rating`, `comment`, `created_at`) VALUES
(1, NULL, 12, 1, 5, 'helow', '2025-07-07 14:24:36'),
(2, NULL, 11, 1, 3, 'nada', '2025-07-07 14:29:06'),
(3, NULL, 12, 5, 3, 'Hola', '2025-07-07 15:00:39'),
(4, NULL, 11, 5, 5, 'Seshhh', '2025-07-07 15:01:02'),
(5, NULL, 13, 1, 3, 'hai', '2025-07-07 15:20:38'),
(6, NULL, 14, 1, 3, 'makanannya enak', '2025-07-07 16:52:19'),
(7, NULL, 9, 1, 3, 'ts\r\n', '2025-07-07 17:04:22'),
(8, NULL, 10, 1, 3, 'z', '2025-07-07 17:06:23'),
(9, NULL, 8, 1, 3, 'aS', '2025-07-07 17:14:34'),
(10, NULL, 16, 1, 3, 'a', '2025-07-08 01:31:10');

-- --------------------------------------------------------

--
-- Table structure for table `review_replies`
--

CREATE TABLE `review_replies` (
  `reply_id` int(11) NOT NULL,
  `review_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reply_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `review_replies`
--

INSERT INTO `review_replies` (`reply_id`, `review_id`, `user_id`, `reply_text`, `created_at`) VALUES
(1, 5, 1, 'h', '2025-07-07 16:19:19'),
(2, 5, 1, 'hh', '2025-07-07 16:19:29'),
(3, 6, 1, 'yayaya', '2025-07-07 16:52:40'),
(4, 7, 1, 'a', '2025-07-07 17:04:30'),
(5, 8, 1, 'xx', '2025-07-07 17:06:32'),
(6, 5, 1, 'jjjjj', '2025-07-07 17:13:11'),
(7, 10, 1, 'a', '2025-07-08 01:31:17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `PASSWORD` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `PASSWORD`, `role`, `created_at`) VALUES
(1, 'Gilangnabhil', '$2y$10$sQscWvZfVIzYtiYofj6Bt.YShCB3Xni.ihSrjrmzEcUvFtBsGEFga', 'admin', '2025-07-07 03:33:03'),
(2, 'gilang', '$2y$10$9rojS1Lln8lEuxU1k3zBK.JOIogRd/XCC3KXh5k5yydlMS2h38F46', 'user', '2025-07-07 06:56:41'),
(3, 'akuabdul', '$2y$10$WRSz/xIEFRSqEaDs40NhsuKjruubCzB8BfZ9E7r/chn2fdAUAN14O', 'user', '2025-07-07 07:35:25'),
(4, 'Tes1', '$2y$10$hWfirua1AVvV4THpMPDjFemqzyFqucSCYifyzCH8f6BgT5Ed3RDxy', 'user', '2025-07-07 08:43:02'),
(5, 'Nada', '$2y$10$EK7ZboyjUwbBlLK.hfZ/E.IOj3R0iAKmWZiMGSy8xD8YNdKKXpzke', 'user', '2025-07-07 15:00:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkins`
--
ALTER TABLE `checkins`
  ADD PRIMARY KEY (`checkin_id`),
  ADD UNIQUE KEY `unique_checkin` (`user_id`,`restaurant_id`),
  ADD UNIQUE KEY `unique_user_restaurant` (`user_id`,`restaurant_id`),
  ADD KEY `restaurant_id` (`restaurant_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`restaurant_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `restaurant_id` (`restaurant_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_parent_review` (`parent_id`);

--
-- Indexes for table `review_replies`
--
ALTER TABLE `review_replies`
  ADD PRIMARY KEY (`reply_id`),
  ADD KEY `review_id` (`review_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `checkins`
--
ALTER TABLE `checkins`
  MODIFY `checkin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `restaurant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `review_replies`
--
ALTER TABLE `review_replies`
  MODIFY `reply_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
